#define _GNU_SOURCE

#include <math.h>
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <poll.h>
#include <termios.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include "mraa.h"
#include "mraa/aio.h"

int period = 1;
int port;
int id;
int socket_fd;
char tempScale = 'f';
int stopflag = 0;
char* filename;
char* host;
int logflag = 0;
time_t timer;
const int B = 4275;               // B value of the thermistor
const int R0 = 100000;            // R0 = 100k
FILE* file;
SSL_CTX *SSL_CTX_new(const SSL_METHOD *method);
int SSL_CTX_up_ref(SSL_CTX *ctx);
const SSL_METHOD *TLSv1_method(void);
//const SSL_METHOD *TLS_server_method(void);
//const SSL_METHOD *TLS_client_method(void);

void loop(mraa_aio_context tempSensor, mraa_gpio_context button, int hours, int mins, int secs, SSL* ssl)
{
    int a = mraa_aio_read(tempSensor);
    int press = mraa_gpio_read(button);
    if(a == -1)
    {
      fprintf(stderr,"Couldn't read temperature from sensor: ", strerror(errno));
      exit(1);
    }
    float R = 1023.0/((float)a)-1.0;
    R = R0*R;
    float temperature = (1.0/(log(R/R0)/B+1/298.15)-273.15); // convert to temperature via datasheet // convert to temperature via datasheet
    if(tempScale == 'f')
    {
      temperature = (temperature*1.8)+32;
    }
    if(press)
    {
      char shutdown[128];
	  sprintf(shutdown,"%.2d:%.2d:%.2d SHUTDOWN\n", hours, mins, secs);
	  SSL_write(ssl,shutdown,strlen(shutdown));
      if(logflag)
	  {
		  fprintf(file,"%.2d:%.2d:%.2d SHUTDOWN\n", hours, mins, secs);
	  }
      mraa_gpio_close(button);
      mraa_aio_close(tempSensor);
      exit(0);
    }
	char weather_report[128];
    sprintf(weather_report,"%.2d:%.2d:%.2d %.2f\n", hours, mins, secs, temperature);
	SSL_write(ssl,weather_report,strlen(weather_report));
    if(logflag)
	{
		fprintf(file,"%.2d:%.2d:%.2d %.2f\n", hours, mins, secs, temperature);;
	}
	sleep(period);
}

void main(int argc, char **argv)
{
	int opt = 0;
	int portflag = 0;
	struct sockaddr_in server_address;
	struct hostent* server_name;
	char id_string[128];
	port = atoi(argv[argc-1]);
	static struct option long_opts[] = 
	{
		{"id", required_argument, 0, 'i'},
		{"log", required_argument, 0, 'l'},
		{"host", required_argument, 0, 'h'}
	};
	while((opt = getopt_long(argc, argv, "i:h:l:", long_opts, NULL)) != -1) 
	{
		switch(opt)
		{
			//--id argument
			case 'i':
				if(strlen(optarg) == 9)
				{
					id = atoi(optarg);
					sprintf(id_string,"ID=%s\n", optarg);
				}
				else
				{
					fprintf(stderr, "Correct usage: ./lab4c_tcp.c <portno> --id=nine-digit_id --host=hostname --log=filename \n");
					exit(1);
				}
				break;
			//--period argument
			case 'h':
				host = optarg;
				break;
			case 'l':
				filename = optarg;
				logflag = 1;
				break;
			//default argument
			default:
				fprintf(stderr, "Correct usage: ./lab4c_tcp.c <portno> --id=nine-digit_id --host=hostname --log=filename \n");
				exit(1);
		}
	}
	//Setup TLS connection
	SSL_load_error_strings();
	OpenSSL_add_ssl_algorithms();
	const SSL_METHOD* method = TLSv1_method();
	SSL_CTX* ctx = SSL_CTX_new(method);
	if(ctx == NULL)
	{
		ERR_print_errors_fp(stderr);
		exit(1);
	}
	socket_fd = socket(AF_INET, SOCK_STREAM, 0);
	if(socket_fd < 0)
	{
		fprintf(stderr, "Unable to create socket: %s \n", strerror(errno));
		exit(1);
	}
	server_name = gethostbyname(host);
	if(server_name == NULL)
	{
		fprintf(stderr, "Cannot find host: %s \n", strerror(errno));
		exit(1);
	}
	bzero((char *) &server_address, sizeof(server_address));
	server_address.sin_family = AF_INET;
	bcopy((char *) server_name->h_addr, (char *) &server_address.sin_addr.s_addr, server_name->h_length);
	server_address.sin_port = htons(port);
	if(connect(socket_fd,(struct sockaddr *) &server_address, sizeof(server_address)) < 0)
	{
		fprintf(stderr,"Unable to connect: %s \n", strerror(errno));
		close(socket_fd);
		exit(1);
	}
	SSL* ssl = SSL_new(ctx);
	if(ssl == NULL)
	{
		ERR_print_errors_fp(stderr);
		exit(1);
	}
	SSL_set_fd(ssl, socket_fd);
	if(SSL_connect(ssl) != 1)
	{
		fprintf(stderr,"Unable to connect with TLS: %s \n",  strerror(errno));
		exit(1);
	}
	SSL_write(ssl,id_string,strlen(id_string));
	//Setup temperature sensor
	mraa_aio_context adc_a0;
	uint16_t adc_value = 0;
	float adc_value_float = 0.0;
	adc_a0 = mraa_aio_init(0);
	if (adc_a0 == NULL)
		exit(1);
	mraa_gpio_context gpio_d3;
	gpio_d3 = mraa_gpio_init(3);
	mraa_gpio_dir(gpio_d3, MRAA_GPIO_IN);
	if(logflag)
	{
		file = fopen(filename, "w");
	}
	char* buffer;
	buffer = (char*)malloc(2048 * sizeof(char));
	int buffersize = 2048;
	struct pollfd fds[1];
	fds[0].fd = socket_fd;
	fds[0].events = POLLIN;
	for(;;)
	{
		struct tm *timeInfo;
		time(&timer);
		timeInfo = localtime(&timer);
		if(stopflag == 0)
			loop(adc_a0,gpio_d3,timeInfo->tm_hour,timeInfo->tm_min,timeInfo->tm_sec,ssl);
		int value = poll(fds, (unsigned long)1, 0);
		if (fds[0].revents & POLLIN) 
		{
			int num_bytes=SSL_read(ssl, buffer, buffersize);
			buffer[num_bytes] = '\0';
			//fprintf(stderr,"%d\n",num_bytes);
			//fprintf(stderr,"%s\n",buffer);
			if(buffer == NULL)
			{
				fprintf(stderr,"Unable to connect: %s \n", strerror(errno));
				close(socket_fd);
				exit(1);
			}
			if(!strcmp(buffer,"STOP\n"))
			{
				//dprintf(socket_fd,"STOP\n");
				if(logflag)
				{
					fprintf(file,"STOP\n");
				}
				stopflag = 1;
			}
			if(!strcmp(buffer,"START\n"))
			{
				//dprintf(socket_fd,"START\n");
				if(logflag)
				{
					fprintf(file,"START\n");
				}
				stopflag = 0;
			}
			if(!strcmp(buffer,"OFF\n"))
			{
				//dprintf(socket_fd,"OFF\n");
				char shutdown[128];
				sprintf(shutdown,"%.2d:%.2d:%.2d SHUTDOWN\n", timeInfo->tm_hour, timeInfo->tm_min, timeInfo->tm_sec);
				SSL_write(ssl,shutdown,strlen(shutdown));
				if(logflag)
				{
					fprintf(file,"OFF\n");
					fprintf(file,"%.2d:%.2d:%.2d SHUTDOWN\n", timeInfo->tm_hour, timeInfo->tm_min, timeInfo->tm_sec);
				}
				SSL_shutdown(ssl);
				close(socket_fd);
				mraa_gpio_close(gpio_d3);
				mraa_aio_close(adc_a0);
				free(buffer);
				exit(0);
			}
			if(!strcmp(buffer,"SCALE=F\n"))
			{
				//dprintf(socket_fd,"SCALE=F\n");
				if(logflag)
				{
					fprintf(file,"SCALE=F\n");
				}
				tempScale = 'f';
			}
			if(!strcmp(buffer,"SCALE=C\n"))
			{	
				//dprintf(socket_fd,"SCALE=C\n");
				if(logflag)
				{
					fprintf(file,"SCALE=C\n");
				}
				tempScale = 'c';
			}
			if(!strncmp(buffer,"PERIOD=",7))
			{
				period = atoi(&buffer[7]);
				//dprintf(socket_fd,"PERIOD=%d\n",period);
				if(logflag)
					fprintf(file,"PERIOD=%d\n",period);
			}
		}
	}
	mraa_gpio_close(gpio_d3);
	mraa_aio_close(adc_a0);
	exit(0);
}