#define _GNU_SOURCE

#include <math.h>
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <poll.h>
#include <termios.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "mraa.h"
#include "mraa/aio.h"

int period = 1;
int port;
int id;
int socket_fd;
char tempScale = 'f';
int stopflag = 0;
char* filename;
char* host;
int logflag = 0;
time_t timer;
const int B = 4275;               // B value of the thermistor
const int R0 = 100000;            // R0 = 100k
FILE* file;

void loop(mraa_aio_context tempSensor, mraa_gpio_context button, int hours, int mins, int secs)
{
    int a = mraa_aio_read(tempSensor);
    int press = mraa_gpio_read(button);
    if(a == -1)
    {
      fprintf(stderr,"Couldn't read temperature from sensor: ", strerror(errno));
      exit(1);
    }
    float R = 1023.0/((float)a)-1.0;
    R = R0*R;
    float temperature = (1.0/(log(R/R0)/B+1/298.15)-273.15); // convert to temperature via datasheet // convert to temperature via datasheet
    if(tempScale == 'f')
    {
      temperature = (temperature*1.8)+32;
    }
    if(press)
    {
		char shutdown[128];
		sprintf(shutdown,"%.2d:%.2d:%.2d SHUTDOWN\n", hours, mins, secs);
		write(socket_fd,shutdown,strlen(shutdown));
		if(logflag)
		{
			fprintf(file,"%.2d:%.2d:%.2d SHUTDOWN\n", hours, mins, secs);
		}
		mraa_gpio_close(button);
		mraa_aio_close(tempSensor);
		exit(0);
    }
    char weather_report[128];
    sprintf(weather_report,"%.2d:%.2d:%.2d %.2f\n", hours, mins, secs, temperature);
	write(socket_fd,weather_report,strlen(weather_report));
    if(logflag)
	{
		fprintf(file,"%.2d:%.2d:%.2d %.2f\n", hours, mins, secs, temperature);;
	}
	sleep(period);
}

void main(int argc, char **argv)
{
	int opt = 0;
	struct sockaddr_in server_address;
	struct hostent* server_name;
	char id_string[128];
	int portflag = 0;
	/*for(int i = 1; i < argc; i++)
	{
		if(argv[i][0] != '-')
		{
			port = atoi(argv[i]);
			fprintf(stderr,"%d\n",port);
			portflag = 1;
		}
	}
	if(portflag != 1)
	{
		fprintf(stderr, "Correct usage: ./lab4c_tcp.c <portno> --id=nine-digit_id --host=hostname --log=filename \n");
		exit(1);
	}*/
	port = atoi(argv[argc-1]);
	static struct option long_opts[] = 
	{
		{"id", required_argument, 0, 'i'},
		{"log", required_argument, 0, 'l'},
		{"host", required_argument, 0, 'h'}
	};
	while((opt = getopt_long(argc, argv, "i:h:l:", long_opts, NULL)) != -1) 
	{
		switch(opt)
		{
			//--id argument
			case 'i':
				if(strlen(optarg) == 9)
				{
					id = atoi(optarg);
					sprintf(id_string,"ID=%s\n", optarg);
				}
				else
				{
					fprintf(stderr, "Correct usage: ./lab4c_tcp.c <portno> --id=nine-digit_id --host=hostname --log=filename \n");
					exit(1);
				}
				break;
			//--period argument
			case 'h':
				host = optarg;
				break;
			case 'l':
				filename = optarg;
				logflag = 1;
				break;
			//default argument
			default:
				fprintf(stderr, "Correct usage: ./lab4c_tcp.c <portno> --id=nine-digit_id --host=hostname --log=filename \n");
				exit(1);
		}
	}
	//Setup TCP connection
	//Initialize Sockets
	socket_fd = socket(AF_INET, SOCK_STREAM, 0);
	if(socket_fd < 0)
	{
		fprintf(stderr, "Unable to create socket: %s \n", strerror(errno));
		exit(1);
	}
	server_name = gethostbyname(host);
	if(server_name == NULL)
	{
		fprintf(stderr, "Cannot find host: %s \n", strerror(errno));
		exit(1);
	}
	bzero((char *) &server_address, sizeof(server_address));
	server_address.sin_family = AF_INET;
	bcopy((char *) server_name->h_addr, (char *) &server_address.sin_addr.s_addr, server_name->h_length);
	server_address.sin_port = htons(port);
	if(connect(socket_fd,(struct sockaddr *) &server_address, sizeof(server_address)) < 0)
	{
		fprintf(stderr,"Unable to connect: %s \n", strerror(errno));
		exit(1);
	}
	write(socket_fd,id_string,strlen(id_string));
	FILE* socket_stream = fdopen(socket_fd,"r+");
	//Setup temperature sensor
	mraa_aio_context adc_a0;
	uint16_t adc_value = 0;
	float adc_value_float = 0.0;
	adc_a0 = mraa_aio_init(0);
	if (adc_a0 == NULL)
		exit(1);
	mraa_gpio_context gpio_d3;
	gpio_d3 = mraa_gpio_init(3);
	mraa_gpio_dir(gpio_d3, MRAA_GPIO_IN);
	if(logflag)
	{
		file = fopen(filename, "w");
	}
	char* buffer;
	buffer = (char*)malloc(2048 * sizeof(char));
	size_t buffersize = 2048;
	struct pollfd fds[1];
	fds[0].fd = socket_fd;
	fds[0].events = POLLIN;
	for(;;)
	{
		struct tm *timeInfo;
		time(&timer);
		timeInfo = localtime(&timer);
		if(stopflag == 0)
			loop(adc_a0,gpio_d3,timeInfo->tm_hour,timeInfo->tm_min,timeInfo->tm_sec);
		int value = poll(fds, (unsigned long)1, 0);
		if (fds[0].revents & POLLIN) 
		{
			getline(&buffer,&buffersize,socket_stream);
			//fprintf(stderr,"%d\n",num_bytes);
			//fprintf(stderr,"%s\n",buffer);
			if(!strcmp(buffer,"OFF\n"))
			{
				//fprintf(stderr,"hi\n");
				char shutdown[128];
				sprintf(shutdown,"%.2d:%.2d:%.2d SHUTDOWN\n", timeInfo->tm_hour, timeInfo->tm_min, timeInfo->tm_sec);
				write(socket_fd,shutdown,strlen(shutdown));
				if(logflag)
				{
					fprintf(file,"OFF\n");
					fprintf(file,"%.2d:%.2d:%.2d SHUTDOWN\n", timeInfo->tm_hour, timeInfo->tm_min, timeInfo->tm_sec);
				}
				break;
			}
			else if(!strcmp(buffer,"STOP\n"))
			{
				//dprintf(socket_fd,"STOP\n");
				if(logflag)
				{
					fprintf(file,"STOP\n");
				}
				stopflag = 1;
			}
			else if(!strcmp(buffer,"START\n"))
			{
				//dprintf(socket_fd,"START\n");
				if(logflag)
				{
					fprintf(file,"START\n");
				}
				stopflag = 0;
			}
			else if(!strcmp(buffer,"SCALE=F\n"))
			{
				//dprintf(socket_fd,"SCALE=F\n");
				if(logflag)
				{
					fprintf(file,"SCALE=F\n");
				}
				tempScale = 'f';
			}
			else if(!strcmp(buffer,"SCALE=C\n"))
			{	
				//dprintf(socket_fd,"SCALE=C\n");
				if(logflag)
				{
					fprintf(file,"SCALE=C\n");
				}
				tempScale = 'c';
			}
			else if(!strncmp(buffer,"PERIOD=",7))
			{
				period = atoi(&buffer[7]);
				//dprintf(socket_fd,"PERIOD=%d\n",period);
				if(logflag)
					fprintf(file,"PERIOD=%d\n",period);
			}
		}
	}
	mraa_gpio_close(gpio_d3);
	mraa_aio_close(adc_a0);
	free(buffer);
	close(socket_fd);
	exit(0);
}