#!/usr/bin/python

import sys
import argparse
import string
import csv
import math

class superblock:
    def __init__(self, num_blk, num_inodes, blk_size, inode_size, blks_per_group, inodes_per_group, first_blk):
        self.num_blk = num_blk
        self.num_inodes = num_inodes
        self.blk_size = blk_size
        self.inode_size = inode_size
        self.blks_per_group = blks_per_group
        self.inodes_per_group = inodes_per_group
        self.first_blk = first_blk

class block:
    def __init__(self, status):
        self.status = status
        self.references = []

class inode:
    def __init__(self, inode_num, file_type, mode, owner, group, link_count, time_change, time_modification, time_access, file_size, inode_num_blocks):
        self.inode_num = inode_num
        self.file_type = file_type
        self.mode = mode
        self.owner = owner
        self.group = group
        self.link_count = link_count
        self.time_change = time_change
        self.time_modification = time_modification
        self.time_access = time_access
        self.file_size = file_size
        self.inode_num_blocks = inode_num_blocks

class group:
        def __init__(self, group_num, num_blocks, num_inodes, num_bfree, num_ifree, bfree_bitmap, ifree_bitmap, i_block):
                self.group_num = group_num
                self.num_inodes = num_inodes
                self.num_bfree = num_bfree
                self.num_ifree = num_ifree
                self.bfree_bitmap = bfree_bitmap
                self.ifree_bitmap = ifree_bitmap
                self.i_block = i_block

def inode_allocation(i_data, sb_data, g_data, ifree_data):
    ret_code = 0
    inode_counter = 0
    for inodes in i_data:
        for free_inode in ifree_data:
            if inodes.inode_num == free_inode and int(inodes.link_count) != 0:
                ret_code = 2
                print("ALLOCATED INODE " + free_inode + " ON FREELIST")
        if int(inodes.link_count) == 0:
            is_there = False
            for free_inode in ifree_data:
                if inodes.inode_num == free_inode:
                    is_there == True
            if is_there == False:
                ret_code = 2
                print("UNALLOCATED INODE " + inodes.inode_num + " NOT ON FREELIST")
        if int(inodes.inode_num) >= int(sb_data.first_blk):
            inode_counter += 1
    if len(ifree_data) < int(g_data.num_ifree):
        missing_counter = int(g_data.num_ifree) - len(i_data)
        prev_inode = int(ifree_data[0])
        atEnd = True
        for free_inode in ifree_data:
            inode_diff = int(free_inode) - prev_inode
            if inode_diff > 1:
                i = 1
                ret_code = 2
                while(i < inode_diff):
                    print("UNALLOCATED INODE %d NOT ON FREELIST" % (int(free_inode)+i))
                    missing_counter -= 1
                    i += 1
            if int(free_inode) == int(g_data.num_inodes):
                atEnd = False
            prev_inode = int(free_inode)
        if missing_counter != 0 and atEnd == False :
            ret_code = 2
            print("UNALLOCATED INODE %d NOT ON FREELIST" % (int(ifree_data[0])-1))
        if missing_counter != 0 and atEnd == True :
            ret_code = 2
            print("UNALLOCATED INODE " + g_data.num_inodes + " NOT ON FREELIST")
    return(ret_code)


def main():
    if(len(sys.argv) != 2):
        sys.stderr.write("Invalid number of arguments.\nUsage: lab3b filename\n")
        exit(1)
    try:
        file = open(sys.argv[1], 'r')
    except:
        sys.stderr.write("Error: Unable to open specified file %s.\n" % sys.argv[1])
        exit(1)
    ret_code = 0
    sb_data = 0
    blocks = {}
    blocks[1] = block('RESERVED')
    blocks[2] = block('RESERVED')
    with file as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            if row[0] == 'SUPERBLOCK':
                sb_data = superblock(int(row[1]), int(row[2]), int(row[3]), int(row[4]), int(row[5]), int(row[6]), int(row[7]))
            if row[0] == 'BFREE':
                if row[1] in blocks:
                    blocks[int(row[1])] = block('DUPLICATE')
                else:
                    blocks[int(row[1])] = block('FREE')

    file = open(sys.argv[1], 'r')
    with file as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            if row[0] == 'GROUP':
                for i in range(1, 9):
                    row[i] = int(row[i])
                blocks[int(row[6])] = block('RESERVED')
                blocks[int(row[7])] = block('RESERVED')
                for i in range(0, int(math.ceil(float(row[3])*128.0/float(sb_data.blk_size)))):
                    blocks[int(row[8]) + i] = block('RESERVED')

    file = open(sys.argv[1], 'r')
    with file as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            if row[0] == 'INODE':
                for element in range(12, 27):
                    row[element] = int(row[element])
                offset = 0
                for i in range(12,27):
                    if row[i] == 0:
                        continue
                    if row[i] in blocks:
                        if blocks[row[i]].status == 'FREE':
                            blocks[row[i]].status = 'FALSELYFREE'
                        if blocks[row[i]].status == 'ALLOCATED':
                            blocks[row[i]].status = 'DUPLICATE'
                            if i < 24:
                                blocks[row[i]].references.append((int(row[1]), 0, i-12))
                            elif i == 24:
                                blocks[row[i]].references.append((int(row[1]), 1, 12))
                            elif i == 25:
                                blocks[row[i]].references.append((int(row[1]), 2, 268))
                            elif i == 26:
                                blocks[row[i]].references.append((int(row[1]), 3, 65804))
                        if blocks[row[i]].status == 'RESERVED':
                            if i < 24:
                                blocks[row[i]].references.append((int(row[1]), 0, i-12))
                            elif i == 24:
                                blocks[row[i]].references.append((int(row[1]), 1, 12))
                            elif i == 25:
                                blocks[row[i]].references.append((int(row[1]), 2, 268))
                            elif i == 26:
                                blocks[row[i]].references.append((int(row[1]), 3, 65804))
                    if sb_data.num_blk < row[i] or row[i] < 0:
                        if row[i] in blocks:
                            if i < 24:
                                blocks[row[i]].references.append((int(row[1]), 0, i-12))
                            elif i == 24:
                                blocks[row[i]].references.append((int(row[1]), 1, 12))
                            elif i == 25:
                                blocks[row[i]].references.append((int(row[1]), 2, 268))
                            elif i == 26:
                                blocks[row[i]].references.append((int(row[1]), 3, 65804))
                        else:
                            blocks[row[i]] = block('INVALID')
                            if i < 24:
                                blocks[row[i]].references.append((int(row[1]), 0, i-12))
                            elif i == 24:
                                blocks[row[i]].references.append((int(row[1]), 1, 12))
                            elif i == 25:
                                blocks[row[i]].references.append((int(row[1]), 2, 268))
                            elif i == 26:
                                blocks[row[i]].references.append((int(row[1]), 3, 65804))
                    elif row[i] not in blocks:
                        blocks[row[i]] = block('ALLOCATED')
                        if i < 24:
                            blocks[row[i]].references.append((int(row[1]), 0, i-12))
                        elif i == 24:
                            blocks[row[i]].references.append((int(row[1]), 1, 12))
                        elif i == 25:
                            blocks[row[i]].references.append((int(row[1]), 2, 268))
                        elif i == 26:
                            blocks[row[i]].references.append((int(row[1]), 3, 65804))
            if row[0] == 'INDIRECT':
                for element in range(1, 6):
                    row[element] = int(row[element])
                if row[5] in blocks:
                    if blocks[row[5]].status == 'ALLOCATED':
                        blocks[row[5]].status = 'DUPLICATE'
                    if blocks[row[5]].status == 'RESERVED':
                        blocks[row[5]].references.append((int(row[1]), row[2] - 1, row[4]))
                if sb_data.num_blk < row[5] or row[5] < 0:
                    if row[5] in blocks:
                        blocks[row[5]].references.append((int(row[1]), row[2] - 1, row[4]))
                    else:
                        blocks[row[5]] = block('INVALID')
                        blocks[row[5]].references.append((int(row[1]), row[2] - 1, row[4]))
                elif row[5] not in blocks:
                        blocks[row[5]] = block('ALLOCATED')
                        blocks[row[5]].references.append((int(row[1]), row[2] - 1, row[4]))
    ifree_data = []
    i_data = []
    alloc_inodes = []
    dir_data = {}
    g_data = None
    file = open(sys.argv[1], 'r')
    with file as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            if row[0] == 'IFREE':
                ifree_data.append(row[1])
            if row[0] == 'INODE':
                i_data.append(inode(row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11]))
                dir_data[int(row[1])] = [int(row[6]),]
                if(int(row[6]) > 0):
                    alloc_inodes.append(int(row[1]))
            if row[0] == 'GROUP':
                g_data = group(row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8])
    
    file = open(sys.argv[1], 'r')
    with file as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            if row[0] == 'DIRENT':
                if int(row[3]) in dir_data:
                    dir_data[int(row[3])].append(int(row[1]))
                if int(row[3]) < 0 or int(row[3]) > int(g_data.num_inodes):
                    ret_code = 2
                    print("DIRECTORY INODE %d NAME %s INVALID INODE %d" % (int(row[1]), row[6], int(row[3])))
                elif int(row[3]) not in alloc_inodes:
                    ret_code = 2
                    print("DIRECTORY INODE %d NAME %s UNALLOCATED INODE %d" % (int(row[1]), row[6], int(row[3])))

    file = open(sys.argv[1], 'r')
    with file as csvfile:
        data = csv.reader(csvfile, delimiter=',')
        for row in data:
            if row[0] == 'DIRENT':
                if row[6] == "\'.\'" and int(row[1]) != int(row[3]):
                    ret_code = 2
                    print("DIRECTORY INODE %d NAME %s LINK TO INODE %d SHOULD BE %d" % (int(row[1]), row[6], int(row[3]), int(row[1])))
                elif row[6] == "\'..\'" and dir_data[int(row[1])][1] != int(row[3]):
                    ret_code = 2
                    print("DIRECTORY INODE %d NAME %s LINK TO INODE %d SHOULD BE %d" % (int(row[1]), row[6], int(row[3]), dir_data[int(row[1])][1]))

    if inode_allocation(i_data, sb_data, g_data, ifree_data) == 2:
        ret_code = 2

    for key in blocks:
        if blocks[key].status == 'INVALID':
            for entry in blocks[key].references:
                ret_code = 2
                if(entry[1] == 0):
                    print("INVALID BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
                elif(entry[1] == 1):
                    print("INVALID INDIRECT BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
                elif(entry[1] == 2):
                    print("INVALID DOUBLE INDIRECT BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
                elif(entry[1] == 3):
                    print("INVALID TRIPPLE INDIRECT BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
        if blocks[key].status == 'RESERVED':
            for entry in blocks[key].references:
                ret_code = 2
                if(entry[1] == 0):
                    print("RESERVED BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
                elif(entry[1] == 1):
                    print("RESERVED INDIRECT BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
                elif(entry[1] == 2):
                    print("RESERVED DOUBLE INDIRECT BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
                elif(entry[1] == 3):
                    print("RESERVED TRIPPLE INDIRECT BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
        if blocks[key].status == 'DUPLICATE':
            for entry in blocks[key].references:
                ret_code = 2
                if(entry[1] == 0):
                    print("DUPLICATE BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
                elif(entry[1] == 1):
                    print("DUPLICATE INDIRECT BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
                elif(entry[1] == 2):
                    print("DUPLICATE DOUBLE INDIRECT BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
                elif(entry[1] == 3):
                    print("DUPLICATE TRIPPLE INDIRECT BLOCK %d IN INODE %d AT OFFSET %d" % (int(key), entry[0], entry[2]))
        if blocks[key].status == 'FALSELYFREE':
            ret_code = 2
            print("ALLOCATED BLOCK %d ON FREELIST" % int(key))
    
    for i in range(1, sb_data.num_blk):
        if i not in blocks:
            ret_code = 2
            print("UNREFERENCED BLOCK %d" % i)

    for key in dir_data:
        if dir_data[key][0] != len(dir_data[key]) - 1:
            ret_code = 2
            print("INODE %d HAS %d LINKS BUT LINKCOUNT IS %d" % (key, len(dir_data[key]) - 1, dir_data[key][0]))
    
    exit(ret_code)

if __name__ == "__main__":
    main()
