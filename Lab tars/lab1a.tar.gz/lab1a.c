#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <termios.h>
#include <sys/poll.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/wait.h>

/*
Name: Sinan Cem Cetin
Email: sinancemcetin@gmail.com
UID: 004664877
*/

//read info stored in buffer
char *buffer;
int BUFFER_SIZE=128;

//saved initial state of terminal for reset
struct termios saved_state;

//if shell is running, this is equal 1, this is when the --shell option is being used.
int shell_flag = 0;

//2 pipes, one to communicate with the shell and the other from the shell.
int pipetoshell_fd[2];
int pipefromshell_fd[2];

struct pollfd fds[2];

//Used to reference the child pid 
pid_t process_id;

void reset_input_mode(void)
{
  tcsetattr(STDIN_FILENO,TCSANOW,&saved_state);
  if(shell_flag)
  {
    int status = 0;
    waitpid(process_id, &status, 0);
    //Used to check the exit status
    fprintf(stderr,"SHELL EXIT SIGNAL=%1$d STATUS=%2$d\n", WTERMSIG(status), WEXITSTATUS(status));
  }
}

//Here be signals that are handled
void signal_handler(int sig_num)
{
  if(shell_flag && (sig_num == SIGINT))
    kill(process_id, SIGINT);
  exit(1);
}

void set_input_mode(void)
{
  struct termios noncanonstate;
  //check to see if stdin is terminal
  if (!isatty(STDIN_FILENO))
  {
    fprintf(stderr, "Error: %s \n", strerror(errno));
    exit(1);
  }
  //Save initial terminal state
  tcgetattr(STDIN_FILENO, &saved_state);
  atexit(reset_input_mode);
  //set new terminal modes
  tcgetattr(STDIN_FILENO, &noncanonstate);
  noncanonstate.c_lflag &= ~(ECHO | ICANON);
  noncanonstate.c_cc[VMIN] = 1;
  noncanonstate.c_cc[VTIME] = 0;
  noncanonstate.c_iflag |= ICRNL;
  if(tcsetattr(STDIN_FILENO, TCSANOW, &noncanonstate)<0)
  {
    fprintf(stderr, "%s \n", strerror(errno));
    exit(1);
  }
}

/*
Reads and writes data into a buffer from fd_read and to fd_write
*/
int read_and_write(int fd_read, int fd_write, int isprocess)
{
  ssize_t bytes_read = read(fd_read,buffer,1);
  int offset = 0;
  int write_flag = 0;
  if(!isprocess && !bytes_read)
    exit(1);
  if(bytes_read < 0)
  {
    fprintf(stderr, "%s \n", strerror(errno));
    exit(1);
  }
  while(bytes_read)
  {
    //Check for CTRL D
    if(*(buffer+offset)==0x4)
    {
      if(shell_flag)
      {
	close(pipetoshell_fd[0]);
  	close(pipetoshell_fd[1]);
  	close(pipefromshell_fd[0]);
        close(pipefromshell_fd[1]);
        kill(process_id,SIGHUP);
      }
      exit(0);
    }
    if(*(buffer+offset)==0x3)
    {
      kill(process_id,SIGINT);
    }
    //Maps <cr> and <lf> to <cr><lf>
    if((*(buffer+offset) == '\r' || *(buffer+offset) == '\n') && !shell_flag)
    {
      char small_buffer[2] = {'\r','\n'};
      write(fd_write, small_buffer, 2);
      if(isprocess)
        write(pipetoshell_fd[1], small_buffer, 2);
      offset++;
      continue;
    }
    write_flag = 0;
    if(bytes_read + offset >= BUFFER_SIZE)
    {
      while(offset < BUFFER_SIZE)
      {
        write(fd_write, buffer+offset, 1);
        if(isprocess) 
	  write(pipetoshell_fd[1], buffer + offset, 1);
        offset++;
        write_flag = 1;
      }
      if(!write_flag) 
      {
        write(fd_write, buffer+offset,1); 
        if(isprocess)
	  write(pipetoshell_fd[1], buffer+offset, 1);
      }
      bytes_read = read(fd_read, buffer,1);
      if(!bytes_read && !isprocess) 
        exit(1);
      offset = 0;
      continue;
    }
    write(fd_write,buffer+offset,1);
    if(isprocess)
      write(pipetoshell_fd[1], buffer+offset, 1);
    offset++;
    bytes_read = read(fd_read, buffer+offset, 1);
    if(!bytes_read && !isprocess)
    {
      exit(1);
    }
  }
  return(0);
}

void make_pipe(int filedescriptor[2])
{
  if(pipe(filedescriptor) == -1)
  {
    fprintf(stderr, "%s \n", strerror(errno));
    exit(1);
  }  
}

void execute_shell()
{
  close(pipetoshell_fd[1]);
  close(pipefromshell_fd[0]);
  dup2(pipetoshell_fd[0], 0);
  dup2(pipefromshell_fd[0], 1);
  dup2(pipefromshell_fd[0], 2);
  if(execvp("/bin/bash",NULL) == -1)
  {
    fprintf(stderr, "%s \n", strerror(errno));
    exit(1);
  }
}

int main(int argc, char **argv)
{
  int opt = 0;
  buffer = (char*)malloc(BUFFER_SIZE * sizeof(char));
  //One option
  static struct option long_opt[] =
  {
    {"shell", no_argument, 0, 's'}
  }; 
  signal(SIGINT, signal_handler);
  signal(SIGPIPE, signal_handler);
  while((opt = getopt_long(argc,argv,"s",long_opt,NULL)) != -1)
  {
    switch(opt)
    {
      case 's':
	shell_flag = 1;
	break;
      default:
        fprintf(stderr, "Correct Usage: lab1a -s \n");
	exit(1);
    }
  }
  set_input_mode();
  //make pipe to and from shell
  make_pipe(pipetoshell_fd);
  make_pipe(pipefromshell_fd);
  if(shell_flag)
  {
    process_id = fork();
    if(process_id == -1)
    {
      fprintf(stderr, "%s \n", strerror(errno)); 
      exit(1);
    }
    //Child process will execute the shell
    if(process_id == 0)
    {
      execute_shell();
    }
    //Parent process will run event loop
    else
    {
      fds[0].fd = pipefromshell_fd[0];
      fds[0].events = POLLIN | POLLHUP | POLLERR;
      fds[1].fd = pipetoshell_fd[1];
      fds[1].events = POLLOUT;
      close(pipetoshell_fd[0]);
      close(pipefromshell_fd[1]);
      while(1) 
      {
	int value = poll(fds, 2, 0);
	if (fds[0].revents & POLLIN) 
        {
	  read_and_write(pipefromshell_fd[0],1,0);
        }
	if (fds[1].revents & POLLOUT) 
        {
	  read_and_write(0,1,1);
        }
        if (fds[0].revents & (POLLHUP+POLLERR)) 
        {
          fprintf(stderr, "%s \n", strerror(errno));
          break;
        }
      }
      exit(0);
    }
  }
  int rwstatus = read_and_write(0,1,1);
  exit(rwstatus);
}
