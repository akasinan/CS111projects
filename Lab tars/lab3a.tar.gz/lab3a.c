// NAME: Eddie Huang, Sinan Cem Cetin
// EMAIL: huang.eddie@yahoo.com, sinancemcetin@gmail.com
// UID: 204607720, 004664877

#include <linux/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include "ext2_fs.h"

int file;
int csv;
int block_size;
int num_groups;
struct ext2_super_block sb_data;

void summarize_super_block()
{
  pread(file, &sb_data, 1024, 1024);
  block_size = 1024 << sb_data.s_log_block_size;
  num_groups = sb_data.s_blocks_count/sb_data.s_blocks_per_group;
  if(sb_data.s_blocks_count % sb_data.s_blocks_per_group > 0)
    num_groups += 1;
  dprintf(csv, "SUPERBLOCK,");
  dprintf(csv, "%d,", sb_data.s_blocks_count);
  dprintf(csv, "%d,", sb_data.s_inodes_count);
  dprintf(csv, "%d,", 1024 << sb_data.s_log_block_size);
  dprintf(csv, "%d,", sb_data.s_inode_size);
  dprintf(csv, "%d,", sb_data.s_blocks_per_group);
  dprintf(csv, "%d,", sb_data.s_inodes_per_group);
  dprintf(csv, "%d\n", sb_data.s_first_ino);
}

void summarize_bitmaps(struct ext2_group_desc g_data)
{
  unsigned char buffer8;
  //Checks groups
  int i;
  for(i = 0; i < num_groups; i++)
    {
      //Checks bytes in block bitmap
      int j;
      for(j = 0; j < block_size; j++)
	{
	  pread(file, &buffer8, 1, (g_data.bg_block_bitmap * block_size) + j);
	  int8_t mask = 1;
	  int k;
	  for(k = 0; k < 8; k++)
	    {
	      int isfree = buffer8 & mask;
	      if(isfree == 0)
		{
		  dprintf(csv,"BFREE,");
		  int freenum = 8*j + (k+1) + (i*sb_data.s_blocks_per_group);
		  dprintf(csv, "%d\n", freenum);
		}
	      mask = mask << 1;
	    }
	}
      //Checks inodes in inode bitmap
      for(j = 0; j < block_size; j++)
	{
	  pread(file, &buffer8, 1, (g_data.bg_inode_bitmap * block_size) + j);
	  int8_t mask = 1;
	  int k;
	  for(k = 0; k < 8; k++)
	    {
	      int isfree = buffer8 & mask;
	      if(isfree == 0)
		{
		  dprintf(csv,"IFREE,");
		  int freenum = 8*j + (k+1) + (i*sb_data.s_inodes_per_group);
		  dprintf(csv, "%d\n", freenum);
		}
	      mask = mask << 1;
	    }
	}
    }
}

void summarize_directory_entries(int curr_block, int i_num)
{
  struct ext2_dir_entry d_data;
  int curr_loc = 0;
  while(curr_loc < block_size)
    {
      pread(file, &d_data, 8 + EXT2_NAME_LEN, 1024 + (curr_block - 1) * block_size + curr_loc);
      if(d_data.name_len == 0)
	return;
      if(d_data.inode)
	{
	  dprintf(csv, "DIRENT,");
	  dprintf(csv, "%d,", i_num);
	  dprintf(csv, "%d,", curr_loc);
	  dprintf(csv, "%d,", d_data.inode);
	  dprintf(csv, "%d,", d_data.rec_len);
	  dprintf(csv, "%d,", d_data.name_len);
	  dprintf(csv, "\'");
	  int j;
	  for(j = 0; j < d_data.name_len; j++)
	    {
	      dprintf(csv, "%c", d_data.name[j]);
	    }
	  dprintf(csv, "\'\n");
	}
      if(!d_data.rec_len)
	return;
      curr_loc += d_data.rec_len;
    }
}

void summarize_indirect(int curr_block, int indirect_level, int offset, int i_num, int is_dir)
{
  if(indirect_level < 1)
    return;
  __u32 block_data;
  int i;
  for(i = 0; i < block_size/4; i++)
    {
      pread(file, &block_data, 4, 1024 + (curr_block - 1) * block_size + 4*i);
      if(!block_data)
	continue;
      int curr_offset = offset + i * (int) pow(block_size/4, indirect_level - 1);
      dprintf(csv, "INDIRECT,");
      dprintf(csv, "%d,", i_num);
      dprintf(csv, "%d,", indirect_level);
      dprintf(csv, "%d,", curr_offset);
      dprintf(csv, "%d,", curr_block);
      dprintf(csv, "%d\n", block_data);
      if(indirect_level <= 1 && !is_dir)
	continue;
      else if(indirect_level <=1 && is_dir)
	summarize_directory_entries(block_data, i_num);
      summarize_indirect(block_data, indirect_level - 1, curr_offset, i_num, is_dir);
    }
}

void summarize_inodes(struct ext2_group_desc g_data)
{
  struct ext2_inode i_data;
  int i;
  for(i = 0; i < sb_data.s_inodes_per_group; i++)
    {
      int is_dir = 0;
      pread(file, &i_data, 128, g_data.bg_inode_table*block_size + 128*i);
      if(i_data.i_mode == 0 || i_data.i_links_count == 0)
	continue;
      dprintf(csv, "INODE,");
      dprintf(csv, "%d,", i + 1);
      if(i_data.i_mode & 0x8000)
	dprintf(csv, "f,");
      else if(i_data.i_mode & 0x4000)
	{
	  dprintf(csv, "d,");
	  is_dir = 1;
	}
      else
	dprintf(csv, "?,");
      dprintf(csv, "%o,", i_data.i_mode & 0777);
      dprintf(csv, "%d,", i_data.i_uid);
      dprintf(csv, "%d,", i_data.i_gid);
      dprintf(csv, "%d,", i_data.i_links_count);
      time_t rawtime = i_data.i_ctime;
      struct tm *ptm;
      ptm = gmtime(&rawtime);
      dprintf(csv, "%02d/%02d/%02d %02d:%02d:%02d,", ptm->tm_mon+1, ptm->tm_mday, ptm->tm_year%100, 
	      ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
      rawtime = i_data.i_mtime;
      ptm = gmtime(&rawtime);
      dprintf(csv, "%02d/%02d/%02d %02d:%02d:%02d,", ptm->tm_mon+1, ptm->tm_mday, ptm->tm_year%100, 
	      ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
      rawtime = i_data.i_atime;
      ptm = gmtime(&rawtime);
      dprintf(csv, "%02d/%02d/%02d %02d:%02d:%02d,", ptm->tm_mon+1, ptm->tm_mday, ptm->tm_year%100, 
	      ptm->tm_hour, ptm->tm_min, ptm->tm_sec);
      dprintf(csv, "%d,", i_data.i_size);
      dprintf(csv, "%d,", i_data.i_blocks);
      int j;
      for(j = 0; j < EXT2_N_BLOCKS - 1; j++)
	{
	  dprintf(csv, "%d,", i_data.i_block[j]);
	}
      dprintf(csv, "%d\n", i_data.i_block[EXT2_N_BLOCKS - 1]);
      if(is_dir)
	{
	  for(j = 0; j < EXT2_N_BLOCKS - 3; j++)
	    {
	      if(!i_data.i_block[j])
		continue;
	      summarize_directory_entries(i_data.i_block[j], i + 1);
	    }
	}
      if(i_data.i_block[EXT2_N_BLOCKS - 3])
	summarize_indirect(i_data.i_block[EXT2_N_BLOCKS - 3], 1, 12, i + 1, is_dir);
      if(i_data.i_block[EXT2_N_BLOCKS - 2])
	summarize_indirect(i_data.i_block[EXT2_N_BLOCKS - 2], 2, 12 + block_size/4, i + 1, is_dir);
      if(i_data.i_block[EXT2_N_BLOCKS - 1])
	summarize_indirect(i_data.i_block[EXT2_N_BLOCKS - 1], 3, 12 + block_size/4 + (int)pow(block_size/4, 2), i + 1, is_dir);
    }

}

void summarize_groups()
{
  struct ext2_group_desc g_data;
  int i;
  for(i = 0; i < num_groups; i++)
    {
      dprintf(csv, "GROUP,");
      dprintf(csv, "%d,", i);
      if(i != num_groups - 1)
	{
	  dprintf(csv, "%d,", sb_data.s_blocks_per_group);
	  dprintf(csv, "%d,", sb_data.s_inodes_per_group);
	}
      else
	{
	  if(sb_data.s_blocks_count/sb_data.s_blocks_per_group != num_groups)
	    dprintf(csv, "%d,", sb_data.s_blocks_count % sb_data.s_blocks_per_group);
	  else
	    dprintf(csv, "%d,", sb_data.s_blocks_per_group);
	  if(sb_data.s_inodes_count/sb_data.s_inodes_per_group != num_groups)
	    dprintf(csv, "%d,", sb_data.s_inodes_count % sb_data.s_inodes_per_group);
	  else
	    dprintf(csv, "%d,", sb_data.s_inodes_per_group);
	}
      pread(file, &g_data, 32, 2048 + 32*i);
      dprintf(csv, "%d,", g_data.bg_free_blocks_count);
      dprintf(csv, "%d,", g_data.bg_free_inodes_count);
      dprintf(csv, "%d,", g_data.bg_block_bitmap);
      dprintf(csv, "%d,", g_data.bg_inode_bitmap);
      dprintf(csv, "%d\n", g_data.bg_inode_table);
      summarize_bitmaps(g_data);
      summarize_inodes(g_data);
    } 
}


int main(int argc, char **argv)
{
  if(argc != 2)
    {
      fprintf(stderr, "Error: Incorrect number of inputs.\n");
      exit(1);
    }
  char* filestr = argv[1];
  file = open(filestr, O_RDONLY);
  if(file < 0)
    {
      fprintf(stderr, "Error: Unable to read specified file.\n");
      exit(2);
    }
  //csv = creat("lab3.csv", 0666);
  csv = 1;
  if(csv < 0)
    {
      fprintf(stderr, "Error: Unable to create csv file.\n");
      exit(2);
    }
  summarize_super_block();
  summarize_groups();
}
