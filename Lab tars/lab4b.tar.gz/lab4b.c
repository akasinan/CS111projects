// Demo code for Grove - Temperature Sensor V1.1/1.2
// Loovee @ 2015-8-26
#define _GNU_SOURCE

#include <math.h>
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <poll.h>
#include "mraa.h"
#include "mraa/aio.h"

int period = 1;
char tempScale = 'f';
char* filename;
int logflag = 0;
time_t timer;
const int B = 4275;               // B value of the thermistor
const int R0 = 100000;            // R0 = 100k
FILE* file;
//Const int pinTempSensor = A0;     // Grove - Temperature Sensor connect to A0

void loop(mraa_aio_context tempSensor, mraa_gpio_context button, int hours, int mins, int secs)
{
    int a = mraa_aio_read(tempSensor);
    int press = mraa_gpio_read(button);
    if(a == -1)
    {
      fprintf(stderr,"Couldn't read temperature from sensor: ", strerror(errno));
      exit(1);
    }
    float R = 1023.0/((float)a)-1.0;
    R = R0*R;
    float temperature = (1.0/(log(R/R0)/B+1/298.15)-273.15); // convert to temperature via datasheet // convert to temperature via datasheet
    if(tempScale == 'f')
    {
      temperature = (temperature*1.8)+32;
    }
    if(press)
    {
      fprintf(stdout,"%.2d:%.2d:%.2d SHUTDOWN\n", hours, mins, secs);
      if(logflag)
	  {
		  fprintf(file,"%.2d:%.2d:%.2d SHUTDOWN\n", hours, mins, secs);
	  }
      mraa_gpio_close(button);
      mraa_aio_close(tempSensor);
      exit(0);
    }
    fprintf(stdout,"%.2d:%.2d:%.2d %.2f\n", hours, mins, secs, temperature);
    if(logflag)
	{
		fprintf(file,"%.2d:%.2d:%.2d %.2f\n", hours, mins, secs, temperature);;
	}
	sleep(period);
}

void main(int argc, char **argv)
{
  int opt = 0;
  static struct option long_opts[] = 
  {
    {"scale", required_argument, 0, 's'},
    {"log", required_argument, 0, 'l'},
    {"period", required_argument, 0, 'p'}
  };
  while((opt = getopt_long(argc, argv, "s:p:l:", long_opts, NULL)) != -1)
  {
    switch(opt)
    {
      //--scale argument
      case 's':
		tempScale = atoi(optarg);
		break;
      //--period argument
      case 'p':
		period = atoi(optarg);
		break;
      case 'l':
		filename = optarg;
		logflag = 1;
		break;
      //default argument
      default:
		fprintf(stderr, "Correct usage: ./lab4b --scale=tempScale --period=period --log=filename \n");
		exit(1);
    }
  }
  mraa_aio_context adc_a0;
  uint16_t adc_value = 0;
  float adc_value_float = 0.0;
  adc_a0 = mraa_aio_init(0);
  if (adc_a0 == NULL)
      exit(1);
  mraa_gpio_context gpio_d3;
  gpio_d3 = mraa_gpio_init(3);
  mraa_gpio_dir(gpio_d3, MRAA_GPIO_IN);
  if(logflag)
  {
    file = fopen(filename, "w");
  }
  char* buffer;
  buffer = (char*)malloc(2048 * sizeof(char));
  int stopflag = 0;
  size_t buffersize = 2048;
  struct pollfd fds[1];
  fds[0].fd = STDIN_FILENO;
  fds[0].events = POLLIN;
  for(;;)
  {
	int value = poll(fds, (unsigned long)1, 0);
	struct tm *timeInfo;
    time(&timer);
    timeInfo = localtime(&timer);
	if (fds[0].revents & POLLIN) 
    {
		getline(&buffer,&buffersize,stdin);
		if(!strcmp(buffer,"OFF\n"))
		{
			fprintf(stdout,"OFF\n");
			fprintf(stdout,"%.2d:%.2d:%.2d SHUTDOWN\n", timeInfo->tm_hour, timeInfo->tm_min, timeInfo->tm_sec);
			if(logflag)
			{
				fprintf(file,"OFF\n");
				fprintf(file,"%.2d:%.2d:%.2d SHUTDOWN\n", timeInfo->tm_hour, timeInfo->tm_min, timeInfo->tm_sec);
			}
			mraa_gpio_close(gpio_d3);
			mraa_aio_close(adc_a0);
			free(buffer);
			exit(0);
		}
		if(!strcmp(buffer,"STOP\n"))
		{
			fprintf(stdout,"STOP\n");
			if(logflag)
			{
				fprintf(file,"STOP\n");
			}
			stopflag = 1;
		}
		if(!strcmp(buffer,"START\n"))
		{
			fprintf(stdout,"START\n");
			if(logflag)
			{
				fprintf(file,"START\n");
			}
			stopflag = 0;
		}
		if(!strcmp(buffer,"SCALE=F\n"))
		{
			fprintf(stdout,"SCALE=F\n");
			if(logflag)
			{
				fprintf(file,"SCALE=F\n");
			}
			tempScale = 'f';
		}
		if(!strcmp(buffer,"SCALE=C\n"))
		{	
			fprintf(stdout,"SCALE=C\n");
			if(logflag)
			{
				fprintf(file,"SCALE=C\n");
			}
			tempScale = 'c';
		}
		if(!strncmp(buffer,"PERIOD=",7))
		{
			period = atoi(&buffer[7]);
			fprintf(stdout,"PERIOD=%d\n",period);
			if(logflag)
				fprintf(file,"PERIOD=%d\n",period);
		}
    }
	if(!stopflag)
		  loop(adc_a0,gpio_d3,timeInfo->tm_hour,timeInfo->tm_min,timeInfo->tm_sec);
  }
  mraa_gpio_close(gpio_d3);
  mraa_aio_close(adc_a0);
  exit(0);
}
