#!/bin/bash
#
LAB="lab4b"
EXPECTED=""
EXPECTEDS="c"
PGM="lab4b"
PGMS=$PGM

TIMEOUT=5

let fail=0

#Creates temp folder to do tests in
TEMP="/tmp/TestTemp.$$"
echo "... Using temporary testing directory" $TEMP
function cleanup {
	cd
	rm -rf $TEMP
	exit $1
}
mkdir $TEMP
cp $PGM $TEMP
cd $TEMP

#Checks to see if it expects usual args
function testrc {
	if [ $1 -ne $2 ]
	then
		echo "ERROR: expected RC=$2, GOT $1"
		let fail+=1
	fi
}

# Checks to see if bogus args are detected.
for p in $PGMS
do
	echo "$p detects bogus arguments"
	if [ -x $p ]
	then
		./$p --bogus > /dev/null 2>STDERR
		testrc $? 1
		if [ ! -s STDERR ]
		then
			echo "Failed bogus argument test"
			let fail+=1
		else
			cat STDERR
		fi
	else
		echo "lab4b program not found"
		let fail+=1
	fi
done

# tests the standard arguments
p=2
s="C"
echo "$PGM supports --scale, --period, --log"
./$PGM --period=$p --scale=$s --log="LOGFILE" <<-EOF
SCALE=F
PERIOD=1
START
STOP
OFF
EOF
ret=$?
if [ $ret -ne 0 ]
then
	echo "Returns incorrect exit code RC=$ret"
	let fail+=1
fi

if [ ! -s LOGFILE ]
then
	echo "Logfile was not created"
	let fail+=1
else
	echo "$PGM supports and logs all sensor commands"
	for c in SCALE=F PERIOD=1 START STOP OFF SHUTDOWN
	do
		grep $c LOGFILE > /dev/null
		if [ $? -ne 0 ]
		then
			echo "lab4b did not log $c"
			let fail+=1
		else
			echo "$c: LOGGED"
		fi
	done

	if [ $fail -gt 0 ]
	then
		echo "   LOG FILE DUMP FOLLOWS   "
		cat LOGFILE
	fi
fi

egrep '[0-9][0-9]:[0-9][0-9]:[0-9][0-9] [0-9][0-9].[0-9]' LOGFILE > /dev/null
if [ $? -eq 0 ] 
then
	echo "Reporting format is correct"
else
	echo REPORTS IN LOGFILE ARE INVALID:
	let fail+=1
	cat LOGFILE
fi

#Returns smoke test results
echo
if [ $fail -eq 0 ]; then
	echo "$PGM passes smoke tests"
	echo
	echo
	cleanup 0
else
	echo "$PGM fails smoke tests with $fail errors"
	echo
	echo
	cleanup -1
fi