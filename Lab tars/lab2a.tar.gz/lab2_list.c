#define _GNU_SOURCE

#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include "SortedList.h"

//Defaults
int iter_num = 1;
int opt_yield = 0; 
int sync_flag = 0;
int lock = 0;
int thread_num = 1;
int list_len = 0;
int runs = 0;
int iflag = 0;
int dflag = 0;
int lflag = 0;

char sync_arg;
char* testname;
const char allowed_yield_args[] = {'i','d','l'};
pthread_mutex_t mutex;
//List and elements
SortedList_t *list;
SortedListElement_t* elements;

void set_yield(char* yield_arg)
{
	for(int i = 0; *(yield_arg+i) != '\0'; i++)
	{
		if(*(yield_arg+i) == allowed_yield_args[0])
		{
			opt_yield |= INSERT_YIELD;
			iflag = 1;
		}
		else if(*(yield_arg+i) == allowed_yield_args[1])
		{
			opt_yield |= DELETE_YIELD;
			dflag = 1;
		}
		else if(*(yield_arg+i) == allowed_yield_args[2])
		{
			opt_yield |= LOOKUP_YIELD;
			lflag = 1;
		}
		else
		{
			fprintf(stderr, "Invalid argument for --yield. --yield=[idl], i - insert, d - delete, l - lookups \n"); 
			exit(1);
		}
	}
}

void setTestName()
{
	switch(sync_arg)
	{
		case 's':
			if(iflag && dflag && lflag)
				testname = "list-idl-s";
			else if(!iflag && dflag && lflag)
				testname = "list-dl-s";
			else if(iflag && !dflag && lflag)
				testname = "list-il-s";
			else if(iflag && dflag && !lflag)
				testname = "list-id-s";
			else if(!iflag && !dflag && lflag)
				testname = "list-l-s";
			else if(iflag && !dflag && !lflag)
				testname = "list-i-s";
			else if(!iflag && dflag && !lflag)
				testname = "list-d-s";
			else
				testname = "list-none-s";
			break;
		case 'm':
			if(iflag && dflag && lflag)
				testname = "list-idl-m";
			else if(!iflag && dflag && lflag)
				testname = "list-dl-m";
			else if(iflag && !dflag && lflag)
				testname = "list-il-m";
			else if(iflag && dflag && !lflag)
				testname = "list-id-m";
			else if(!iflag && !dflag && lflag)
				testname = "list-l-m";
			else if(iflag && !dflag && !lflag)
				testname = "list-i-m";
			else if(!iflag && dflag && !lflag)
				testname = "list-d-m";
			else
				testname = "list-none-m";
			break;
		default:
			if(iflag && dflag && lflag)
				testname = "list-idl-none";
			else if(!iflag && dflag && lflag)
				testname = "list-dl-none";
			else if(iflag && !dflag && lflag)
				testname = "list-il-none";
			else if(iflag && dflag && !lflag)
				testname = "list-id-none";
			else if(!iflag && !dflag && lflag)
				testname = "list-l-none";
			else if(iflag && !dflag && !lflag)
				testname = "list-i-none";
			else if(!iflag && dflag && !lflag)
				testname = "list-d-none";
			else
				testname = "list-none-none";
			break;
	}
}

void rand_keys()
{
	srand(time(NULL));
	for(int i = 0; i < runs; i++)
	{
		char* key = malloc(11*sizeof(char));
		for(int j = 0; j < 10; j++)
		{
			char letter = 'a' + (rand() % 26);
			key[j] = letter;
		}
		key[10] = '\0';
		elements[i].key = key;
	}
}

void* list_with_threads(void* num_threads)
{
	for(int i = *(int*)num_threads; i < runs; i += thread_num)
	{
		switch(sync_arg)
		{
			case 'm':
				pthread_mutex_lock(&mutex);
				SortedList_insert(list, &elements[i]); 
				pthread_mutex_unlock(&mutex);
				break;
			case 's':
				while(__sync_lock_test_and_set(&lock, 1));
				SortedList_insert(list, &elements[i]);
				__sync_lock_release(&lock);
				break;
			default:
				SortedList_insert(list, &elements[i]);
				break;
		}
	}
	list_len = SortedList_length(list);
	SortedListElement_t *deletthis;
	//Lookup and delete based on locking, with the same indexing as before
	for(int j = *(int*)num_threads; j < runs; j += thread_num)
	{
		switch(sync_arg)
		{
			case 'm':
				pthread_mutex_lock(&mutex);
				deletthis = SortedList_lookup(list, elements[j].key);
				if(deletthis == NULL)
				{
					fprintf(stderr,"Error: Corrupted list, Inserted Element not found. \n");
					exit(2);
				}
				SortedList_delete(deletthis);
				pthread_mutex_unlock(&mutex);
				break;
			case 's':
				while(__sync_lock_test_and_set(&lock, 1));
				deletthis = SortedList_lookup(list, elements[j].key);
				if(deletthis == NULL)
				{
					fprintf(stderr,"Error: Corrupted list, Inserted Element not found. \n");
					exit(2);
				}
				SortedList_delete(deletthis);
				__sync_lock_release(&lock);
				break;
			default:
				deletthis = SortedList_lookup(list, elements[j].key);
				if(deletthis == NULL)
				{
					fprintf(stderr,"Error: Corrupted list, Inserted Element not found. \n");
					exit(2);
				}
				SortedList_delete(deletthis);
				break;
		}
	}
	list_len = SortedList_length(list);
	return NULL;
}

int main(int argc, char **argv)
{
	//Store the number of threads and iterations, default to 1, 
	//the exit status is 0 (except for errors)
	int opt = 0;
	struct timespec start;
	struct timespec end;
	static struct option long_opts[] = 
	{
		{"threads", required_argument, 0, 't'},
		{"yield", required_argument, 0, 'y'},
		{"sync", required_argument, 0, 's'},
		{"iterations", required_argument, 0, 'i'}
	};

	while((opt = getopt_long(argc, argv, "t:i:", long_opts, NULL)) != -1)
	{
		switch(opt)
		{
			//--threads argument
			case 't':
				thread_num = atoi(optarg);
				break;
			//--iterations argument
			case 'i':
				iter_num = atoi(optarg);
				break;
			//--yield argument
			case 'y':
				set_yield(optarg);
				break;
			//--sync argument
			case 's':
				sync_flag = 1;
				if(strlen(optarg) == 1 && optarg[0] == 'm') 
				{
					sync_arg = 'm';
				}
				else if(strlen(optarg) == 1 && optarg[0] == 's') 
				{
					sync_arg = 's';
				}
				else
				{
					fprintf(stderr, "Invalid argument for --sync. Use one of the following: m - mutex, s - spin-lock \n"); 
					exit(1); 
				}
				break;
			default:
				fprintf(stderr, "Correct usage: ./lab2_list --threads=thread_num --iterations=iter_num --yield=[idl] --sync=[sm]");
				exit(1);
		}
	}
	setTestName();
	if(sync_arg == 'm')
		pthread_mutex_init(&mutex,NULL);
	runs = iter_num * thread_num;
	
	//initialize linked list
	list = malloc(sizeof(SortedList_t));
	list->key = NULL;
	list->next=list;
	list->prev=list;
	
	elements = malloc(runs * sizeof(SortedListElement_t));
	rand_keys();
	//allocates memory for threads and thread id's
	pthread_t *threads = malloc(thread_num * sizeof(pthread_t));
	int* thread_ids = malloc(thread_num * sizeof(int));
	
	//start timer
	if(clock_gettime(CLOCK_MONOTONIC,&start) == -1)
	{
		fprintf(stderr,"Time start error: %s \n",strerror(errno));
		exit(2);
	}
	//Make threads
	for(int i = 0; i < thread_num; i++)
	{
		thread_ids[i] = i;
		if(pthread_create(threads + i, NULL, list_with_threads, &thread_ids[i]))
		{
			fprintf(stderr,"Thread creation error: %s \n",strerror(errno));
			exit(2);
		}
	}
	//Join threads
	for(int j = 0; j < thread_num; j++)
	{
		if(pthread_join(threads[j], NULL))
		{
			fprintf(stderr,"Thread joining error: %s \n",strerror(errno));
			exit(2);
		}
	}
	//stop timer
	if(clock_gettime(CLOCK_MONOTONIC,&end) == -1)
	{
		fprintf(stderr,"Clock end error: %s \n",strerror(errno));
		exit(2);
	}
	
	//free stuff
	free(thread_ids);
	free(elements);
	free(threads);
	
	long total_time = 1000000000 * (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec);
	int number_of_ops = runs * 3;
	long per_time = total_time / number_of_ops;
	
	if(list_len != 0)
	{
		fprintf(stderr,"Error: Corrupted List, List length is %d. \n",list_len);
		exit(2);
	}
	
	fprintf(stdout, "%s,%d,%d,1,%d,%d,%d\n", testname, thread_num, iter_num, number_of_ops,total_time,per_time);
	exit(0);
}