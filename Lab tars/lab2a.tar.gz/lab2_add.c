#define _GNU_SOURCE

#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <fcntl.h>

//Defaults
int iter_num = 1;
int opt_yield = 0; 
int lock = 0;

//sync_arg and the mutex for when sync_arg = 'm'
char sync_arg;
pthread_mutex_t mutex;

void add(long long *pointer, long long value) 
{
    long long sum = *pointer + value;
    if (opt_yield)
        sched_yield();
    *pointer = sum;
}

//add but using compare and swap
void add_compare_swap(long long *pointer, long long value)
{
    long long old;
	long long sum; 
	do{
		old = *pointer;
		sum = old + value;
		if (opt_yield)
			sched_yield();
	}while(__sync_val_compare_and_swap(pointer,old,sum)!= old);
}

//Function run by thread
void* add_with_threads(void* counter)
{
	//add by 1
	for(int i = 0; i < iter_num; i++)
	{
		if(sync_arg == 'm') //mutex lock
		{
			pthread_mutex_lock(&mutex);
			add((long long*) counter, 1);
			pthread_mutex_unlock(&mutex);
		}
		else if(sync_arg == 's') //spin lock
		{
			while(__sync_lock_test_and_set(&lock, 1));
			add((long long*) counter, 1);
			__sync_lock_release(&lock);
		}
		else if(sync_arg == 'c') //compare and swap
		{
			add_compare_swap((long long*) counter, 1);
		}
		else //regular add
		{
			add((long long*) counter, 1);
		}
	}
	//add by -1
	for(int j = 0; j < iter_num; j++)
	{
		if(sync_arg == 'm')
		{
			pthread_mutex_lock(&mutex);
			add((long long*) counter, -1);
			pthread_mutex_unlock(&mutex);
		}
		else if(sync_arg == 's')
		{
			while(__sync_lock_test_and_set(&lock, 1));
			add((long long*) counter, -1);
			__sync_lock_release(&lock);
		}
		else if(sync_arg == 'c')
		{
			add_compare_swap((long long*) counter, -1);
		}
		else
			add((long long*) counter, -1);
	}
	return NULL;
}

int main(int argc, char **argv)
{
	//Store the number of threads and iterations, default to 1, 
	//the exit status is 0 (except for errors)
	int opt = 0;
    int thread_num = 1;
	int exit_status = 0;
	int sync_flag = 0;
	char* testname;
	struct timespec start;
	struct timespec end;
	static struct option long_opts[] = 
	{
		{"threads", required_argument, 0, 't'},
		{"yield", no_argument, 0, 'y'},
		{"sync", required_argument, 0, 's'},
		{"iterations", required_argument, 0, 'i'}
	};

	while((opt = getopt_long(argc, argv, "t:i:", long_opts, NULL)) != -1)
	{
		switch(opt)
		{
			//--threads argument
			case 't':
				thread_num = atoi(optarg);
				break;
			//--iterations argument
			case 'i':
				iter_num = atoi(optarg);
				break;
			//--yield argument
			case 'y':
				opt_yield = 1;
				testname = "add-yield-none";
				break;
			//--sync argument
			case 's':
				sync_flag = 1;
				if(strlen(optarg) == 1 && optarg[0] == 'm') 
				{
					sync_arg = 'm';
					if(opt_yield == 1)
						testname = "add-yield-m";
					else
						testname = "add-m";
				}
				else if(strlen(optarg) == 1 && optarg[0] == 's') 
				{
					sync_arg = 's';
					if(opt_yield == 1)
						testname = "add-yield-s";
					else
						testname = "add-s";
				}
				else if(strlen(optarg) == 1 && optarg[0] == 'c') 
				{
					sync_arg = 'c';
					if(opt_yield == 1)
						testname = "add-yield-c";
					else
						testname = "add-c";
				}
				else
				{
					fprintf(stderr, "Invalid argument for --sync. Use one of the following: m - mutex, s - spin-lock, c - compare and swap \n"); 
					exit(2); 
				}
				break;
			default:
				fprintf(stderr, "Correct usage: lab2_add --threads=thread_num  --iterations=iter_num --yield --sync=[smc]");
				exit(1);
		}
	}
	if(opt_yield == 0 && sync_flag == 0)
	{
		testname = "add-none";
	}
	pthread_t *threads = malloc(thread_num*sizeof(pthread_t));
	//Initialize counter
	long long counter = 0;
	//Initialize mutex if sync_arg = 'm'
	if(sync_arg == 'm')
		pthread_mutex_init(&mutex, NULL);
	if(clock_gettime(CLOCK_MONOTONIC,&start) == -1)
	{
		fprintf(stderr,"Time start error: %s \n",strerror(errno));
		exit(2);
	}
	//Make threads
	for(int i = 0; i < thread_num; i++)
	{
		if(pthread_create(threads + i, NULL, add_with_threads, &counter))
		{
			fprintf(stderr,"Thread creation error: %s \n",strerror(errno));
			exit(2);
		}
	}
	//Join threads
	for(int j = 0; j < thread_num; j++)
	{
		if(pthread_join(*(threads + j), NULL))
		{
			fprintf(stderr,"Thread joining error: %s \n",strerror(errno));
			exit(2);
		}
	}
	//stop timer
	if(clock_gettime(CLOCK_MONOTONIC,&end) == -1)
	{
		fprintf(stderr,"Clock end error: %s \n",strerror(errno));
		exit(2);
	}
	long total_time = 1000000000 * (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec);
	int number_of_ops = thread_num * iter_num * 2;
	long per_time = total_time / number_of_ops;
	
	fprintf(stdout, "%s,%d,%d,%d,%d,%d,%d\n", testname, thread_num, iter_num, number_of_ops,total_time,per_time,counter);
	
	//FILE* file_fd = fopen("lab2_add.csv","a+");
	//fprintf(file_fd, "%s,%d,%d,%d,%d,%d,%d\n", testname, thread_num, iter_num, number_of_ops,total_time,per_time,counter);
	
	if(counter)
	{
		exit_status = 1;
	}
	exit(exit_status);
}